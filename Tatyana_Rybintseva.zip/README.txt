Please follow the steps to test the API for pets and store:
1. Install the Postman https://www.getpostman.com/apps 
2. Import the Dev Challenge.postman_collection.
3. Run the tests.

